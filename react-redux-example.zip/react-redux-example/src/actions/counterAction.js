/* actions related to the counter */
export const counterIncrement = e => {
    return {
        type: "INCREMENT"
    };
};

export const counterDecrement = e => {
    return {
        type: "DECREMENT"
    };
};
